from pyflakes.api import main

# python -m pyflakes (with Python >= 2.7)
if __name__ == '__main__':
    main(prog='pyflakes')
