document.location.href =
    "https://docs.google.com/document/create?usp=chrome_app&authuser=0";
